#include <asm-generic/trace_clock.h>
